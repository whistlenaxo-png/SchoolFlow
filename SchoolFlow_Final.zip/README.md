# SchoolFlow Final

This is the finalized local-first edition of SchoolFlow.

## Works immediately
- Add assignments and projects
- Track subjects
- Set due dates and priorities
- Mark work complete
- Search and filter
- Works offline after the first hosted load
- Stores data on your device
- Export/import backups
- Installable as a PWA on modern phones and computers

## Install
A PWA must be served from HTTPS (or localhost while developing).

Once hosted:
- iPhone/iPad: open in Safari → Share → Add to Home Screen
- Android: open in Chrome → Install app / Add to Home Screen
- Windows/macOS: open in Chrome or Edge → Install App

Opening `SchoolFlow.html` directly still works as a basic local organizer, but browser security rules prevent full PWA installation from `file://`.

## Data
SchoolFlow stores tasks in the browser's localStorage. Use Settings → Export backup if you want to move your data to another device.
